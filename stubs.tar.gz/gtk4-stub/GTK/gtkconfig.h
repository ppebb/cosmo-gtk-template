#ifndef __GTKCONFIG_H__
#define __GTKCONFIG_H__

#if !defined (__GTK_H_INSIDE__) && !defined (GTK_COMPILATION)
#error "Only <gtk/gtk.h> can be included directly."
#endif

#include <glib.h>

G_BEGIN_DECLS

#define GTK_ACCESSIBILITY_ATSPI

G_END_DECLS

#endif  /* __GTKCONFIG_H__ */
